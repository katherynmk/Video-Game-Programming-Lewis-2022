#include "Frog.h"
#include "MainMenu.h"
#include "MainGame.h"
#include "MainUpdate.h"
#include <iostream>
#include <fstream>

using namespace Webfoot;

/// Which interface should be shown for this state.
#define GUI_LAYER_NAME "MainMenu"

MainMenu MainMenu::instance;

//-----------------------------------------------------------------------------

void MainMenu::Init()
{
   Inherited::Init();
   exitingGame = false;
}

//-----------------------------------------------------------------------------

void MainMenu::OnGUILayerInit(LayerWidget*)
{
   // Set up the GUI callbacks.
   PressButtonWidget::OnClickRegister(GUI_LAYER_NAME ".bg", NULL);
   PressButtonWidget::OnClickRegister(GUI_LAYER_NAME ".Play", OnPlayClick);
   PressButtonWidget::OnClickRegister(GUI_LAYER_NAME ".Exit", OnExitClick);
   PressButtonWidget::OnClickRegister(GUI_LAYER_NAME ".Multiplayer", OnPlayMultiClick);
   PressButtonWidget::OnClickRegister(GUI_LAYER_NAME ".pong", NULL);
}

//-----------------------------------------------------------------------------

void MainMenu::Deinit()
{
   if(exitingGame)
      theMainUpdate->Exit();

   Inherited::Deinit();
}

//-----------------------------------------------------------------------------

const char* MainMenu::GUILayerNameGet()
{
   return GUI_LAYER_NAME;
}

//-----------------------------------------------------------------------------

void MainMenu::OnPlayClick(PressButtonWidget*, void*)
{
	std::ofstream MyFile("data.txt");
	MyFile << "0";

	MyFile.close();
   if(!theStates->StateChangeCheck() && !theMainUpdate->ExitingCheck())
   {
      theMainMenu->StateChangeTransitionBegin(true);
      theStates->Push(theMainGame);
   }
}

//-----------------------------------------------------------------------------

void MainMenu::OnExitClick(PressButtonWidget*, void*)
{
   if(!theStates->StateChangeCheck() && !theMainUpdate->ExitingCheck())
   {
      theMainMenu->StateChangeTransitionBegin(true);
      theMainMenu->exitingGame = true;
      theStates->Pop();
   }
}

//-----------------------------------------------------------------------------

void MainMenu::OnPlayMultiClick(PressButtonWidget*, void*)
{
	std::ofstream MyFile("data.txt");
	MyFile << "1";

	MyFile.close();
	if (!theStates->StateChangeCheck() && !theMainUpdate->ExitingCheck())
	{
		theMainMenu->StateChangeTransitionBegin(true);
		theStates->Push(theMainGame);
	}
}