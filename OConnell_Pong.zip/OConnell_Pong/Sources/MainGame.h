#ifndef __MAINGAME_H__
#define __MAINGAME_H__

#include "Frog.h"
#include "MenuState.h"

namespace Webfoot {

class Ball;
class Paddle;
class Player;
class AI;
struct Stats;

//==============================================================================

class MainGame : public MenuState
{
public:
   typedef MenuState Inherited;

   MainGame();
   virtual ~MainGame() {};
   
   virtual void Init();
   virtual void Deinit();

   /// Call this on every frame to update the positions.
   virtual void Update();
   /// Call this on every frame to draw the images.
   virtual void Draw();

   static MainGame instance;

protected:
   /// Returns the name of the GUI layer
   virtual const char* GUILayerNameGet();

   Paddle* objects[2];

   /// The ball that bounces around the screen.
   Ball* ball;
   Player *player;
   AI *ai;
   Stats* stats;
   Sound* sounds[5];
};

MainGame* const theMainGame = &MainGame::instance;


//==============================================================================

/// A bouncing ball
class Ball
{
public:
   Ball();
   
   /// Initialize the ball
   void Init();
   /// Clean up the ball
   void Deinit();

   /// Make any changes for the given frame.  'dt' is the amount of time that
   /// has passed since the last frame, in milliseconds.
   bool Update(unsigned int dt, Paddle* objects[]);
   /// Draw the ball.
   void Draw();

   Point2F getPosition();

protected:
   /// Appearance of the ball.
   Image* image;
   /// Current position of the ball.
   Point2F position;


   int dirX;
   int dirY;
   int speed;
   float halfSize;
};

class Paddle
{
public:
	Point2F position;
	Image* image;

	Paddle();

	virtual void Init();
	void Deinit();
	virtual void Update(unsigned int dt);
	void Draw();

	virtual int getCollision(float ballX, float ballY, float ballDirX, float ballRadius);


};

class Player: public Paddle
{
public:
	Player();

	void Init();
	void Update(unsigned int dt);
	int getCollision(float ballX, float ballY, float ballDirX, float ballRadius);

};

class AI : public Paddle
{
public:
	AI(bool isPlayer = false);

	void Init();
	void Update(unsigned int dt, Point2F ballPos);

	int getCollision(float ballX, float ballY, float ballDirX, float ballRadius);
private:
	bool isPlayer;
	int dir;
};

struct Stats{
	int playerScore;
	int aiScore;
	int winCon;
	int playedFlag;
	int gameMode;

};

//==============================================================================

} //namespace Webfoot {

#endif //#ifndef __MAINGAME_H__
