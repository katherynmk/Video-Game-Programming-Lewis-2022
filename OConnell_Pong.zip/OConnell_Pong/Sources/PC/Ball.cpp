#include <random>
#include <chrono>
#include "Frog.h"
#include "MainGame.h"
#include "MainUpdate.h"

#define PI 3.14159265

using namespace Webfoot;

std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
Ball::Ball()
{
	// Initialize pointers to NULL for safety.
	image = NULL;
}

//------------------------------------------------------------------------------

void Ball::Init()
{
	// Load the image of the ball.
	image = theImages->Load("Ball");

	std::random_device dev;
	std::mt19937 rng(dev());
	std::uniform_int_distribution<std::mt19937::result_type> dist(0, 1);


	speed = 9;
	if (dist(rng) == 0){
		dirX = speed;
	}
	else{
		dirX = -speed;
	}

	dirY = 0;
	halfSize = image->WidthGet() / 2.0f;

	// Start the ball in the middle of the screen.
	position = Point2F::Create(theScreen->SizeGet() / 2);

	begin = std::chrono::steady_clock::now();
}

//------------------------------------------------------------------------------

void Ball::Deinit()
{
	// Unload the image of the ball.
	if (image)
	{
		theImages->Unload(image);
		image = NULL;
	}
}

//------------------------------------------------------------------------------


bool Ball::Update(unsigned int dt, Paddle* objects[])
{
	Point2F positionScreen = Point2F::Create(theScreen->SizeGet()); //1024 by 768.

	auto elapsed = std::chrono::steady_clock::now();
	if (std::chrono::duration_cast<std::chrono::seconds>(elapsed - begin).count() > 5){

		speed++;

		begin = elapsed;
	}

	int col = objects[0]->getCollision(position.x, position.y, dirX, halfSize);
	
	switch (col){
	case 1:
		dirX = speed*cos((5 * PI) / 3);
		dirY = speed*sin((5 * PI) / 3);
		return true;
		break;
	case 2:
		dirX = speed*cos((11 * PI) / 6);
		dirY = speed*sin((11 * PI) / 6);
		return true;
		break;
	case 3:
		dirX = speed*cos(0);
		dirY = speed*sin(0);
		return true;
		break;
	case 4:
		dirX = speed*cos(PI / 6);
		dirY = speed*sin(PI / 6);
		return true;
		break;
	case 5:
		dirX = speed*cos(PI / 3);
		dirY = speed*sin(PI / 3);
		return true;
		break;
	default:
		break;
	}
	
	col = objects[1]->getCollision(position.x, position.y, dirX, halfSize);

	switch (col){
	case 1:
		dirX = speed*cos((4 * PI) / 3);
		dirY = speed*sin((4 * PI) / 3);
		return true;
		break;
	case 2:
		dirX = speed*cos((7 * PI) / 6);
		dirY = speed*sin((7 * PI) / 6);
		return true;
		break;
	case 3:
		dirX = speed*cos(PI);
		dirY = speed*sin(PI);
		return true;
		break;
	case 4:
		dirX = speed*cos((5 * PI) / 6);
		dirY = speed*sin((5 * PI) / 6);
		return true;
		break;
	case 5:
		dirX = speed*cos((2 * PI) / 3);
		dirY = speed*sin((2 * PI) / 3);
		return true;
		break;
	default:
		break;
	}

	
	if (positionScreen.y < (position.y + halfSize) && dirY > 0){
		dirY *= -1;
	}
	else if (position.y < halfSize && dirY < 0){
		dirY *= -1;
	}
	

	position.Set(position.x + dirX, position.y + dirY);
	return false;
}



//------------------------------------------------------------------------------

void Ball::Draw()
{
	// The center of the ball is in the center of the image, so use an offset.
	image->Draw(position - (Point2F::Create(image->SizeGet()) / 2.0f));
}

//------------------------------------------------------------------------------


Point2F Ball::getPosition(){
	return position;
}