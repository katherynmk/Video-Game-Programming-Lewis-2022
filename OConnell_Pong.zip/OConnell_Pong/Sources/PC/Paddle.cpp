#include "Frog.h"
#include "MainGame.h"
#include "MainUpdate.h"

using namespace Webfoot;

Paddle::Paddle(){
	image = NULL;
}

void Paddle::Init(){
	image = theImages->Load("Paddle");

	position = Point2F::Create(theScreen->WidthGet() / 8, theScreen->HeightGet() / 2.5);
}
void Paddle::Deinit(){
	if (image)
	{
		theImages->Unload(image);
		image = NULL;
	}
}
void Paddle::Update(unsigned int dt){

	
}
void Paddle::Draw(){
	image->Draw(position);
}

int Paddle::getCollision(float ballX, float ballY, float ballDirX, float ballRadius){

	if ((ballY + ballRadius) >= position.y && (ballX > position.x && ballX < position.x + image->WidthGet()) && ballDirX < 0){
		return 1;
	}

	return 0;
}
