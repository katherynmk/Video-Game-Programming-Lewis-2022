#include "Frog.h"
#include "MainGame.h"
#include "MainUpdate.h"

using namespace Webfoot;

Player::Player(){
	image = NULL;
}

void Player::Init(){
	image = theImages->Load("Paddle");
	position = Point2F::Create(theScreen->WidthGet() / 9, theScreen->HeightGet() / 2.5);
}

void Player::Update(unsigned int dt){
	Point2F positionScreen = Point2F::Create(theScreen->SizeGet());

	if (!theStates->StateChangeCheck() && theKeyboard->KeyPressed(KEY_W) && position.y > 0)
	{
		position.y -= 6;
	}
	if (!theStates->StateChangeCheck() && theKeyboard->KeyPressed(KEY_S) && (position.y + image->HeightGet()) < positionScreen.y)
	{
		position.y += 6;
	}
}

int Player::getCollision(float ballX, float ballY, float ballDirX, float ballRadius){
	float height = image->HeightGet();

	float seg1 = (height / 5.0F) + position.y;
	float seg2 = ((height / 5.0F) * 2) + position.y;
	float seg3 = ((height / 5.0F) * 3) + position.y;
	float seg4 = ((height / 5.0F) * 4) + position.y;

	if (ballDirX < 0 && ballY >= position.y && ballY <= position.y + height && ballX - ballRadius < position.x + image->WidthGet() && ballX > position.x){

		if (ballY <= seg1 && ballY >= position.y){
			return 1;
		}
		if (ballY <= seg2 && ballY >= seg1){
			return 2;
		}
		if (ballY <= seg3 && ballY >= seg2){
			return 3;
		}
		if (ballY <= seg4 && ballY >= seg3){
			return 4;
		}
		if (ballY <= position.y + height && ballY >= seg4){
			return 5;
		}
	}

	return 0;
}
