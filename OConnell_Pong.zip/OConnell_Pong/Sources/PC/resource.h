#ifndef __RESOURCE_H__
#define __RESOURCE_H__

#define IDI_MAIN           101
#define IDC_MAIN           201

#endif //#ifndef __RESOURCE_H__
