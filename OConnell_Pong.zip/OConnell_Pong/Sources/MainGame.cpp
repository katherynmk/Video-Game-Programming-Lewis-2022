#include <windows.h>
#include "Frog.h"
#include "MainGame.h"
#include "MainUpdate.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace Webfoot;

MainGame MainGame::instance;

//==============================================================================

/// Main GUI
#define GUI_LAYER_NAME "MainGame"

//-----------------------------------------------------------------------------

const char* SOUND_PATHS[] =
{
	"Sounds/hit",
	"Sounds/score",
	"Sounds/start",
	"Sounds/victory",
	"Sounds/defeat"
};

enum Sounds
{
	HIT,
	SCORE,
	START,
	VICTORY,
	DEFEAT
};

MainGame::MainGame()
{
   ball = NULL;
   player = NULL;
   ai = NULL;
   objects[0] = NULL;
   stats = NULL;
}

//-----------------------------------------------------------------------------

void MainGame::Init()
{
   Inherited::Init();

   for (int i = 0; i < 5; i++)
	   sounds[i] = theSounds->Load(SOUND_PATHS[i]);

   sounds[START]->Play(NULL, false);

   stats = new Stats;
   stats->playerScore = 0;
   stats->aiScore = 0;
   stats->winCon = 0;
   
   ball = frog_new Ball();
   ball->Init();

   player = frog_new Player();
   player->Init();

   std::string text;
   std::ifstream readData("data.txt");
   
   std::getline(readData, text);

   readData.close();
   if (text == "1"){
	   stats->gameMode = 1;
	   ai = frog_new AI(true);
   }
   else{
	   stats->gameMode = 0;
	   ai = frog_new AI(false);
   }
   ai->Init();

   objects[0] = player;
   objects[1] = ai;

   stats->playedFlag = 0;
}

//-----------------------------------------------------------------------------

void MainGame::Deinit()
{
   if(ball)
   {
      ball->Deinit();
      frog_delete ball;
      ball = NULL;
   }

   if (player){
	   player->Deinit();
	   frog_delete player;
	   player = NULL;
   }

   if (ai){
	   ai->Deinit();
	   frog_delete ai;
	   ai = NULL;
   }
   if (stats){
	   delete stats;
	   stats = NULL;
   }

   for (int i = 0; i < 5; i++)
	theSounds->Unload(SOUND_PATHS[i]);
   
   Inherited::Deinit();
}

//-----------------------------------------------------------------------------

const char* MainGame::GUILayerNameGet()
{
   return GUI_LAYER_NAME;
}

//-----------------------------------------------------------------------------

void MainGame::Update()
{
   Inherited::Update();

   unsigned int dt = theClock->LoopDurationGet();
   Point2F ballPos = ball->getPosition();

   if ((*stats).playerScore > 14){
	   stats->winCon = 1;
	   return;
   }
   else if ((*stats).aiScore > 14){
	   stats->winCon = -1;
	   return;
   }

   if (ballPos.x < 50){
	   sounds[SCORE]->Play(NULL, false);
	   ball->Deinit();
	   ball->Init();
	   player->Deinit();
	   player->Init();
	   ai->Deinit();
	   ai->Init();
	   (*stats).aiScore += 1;
   }
   else if (ballPos.x > theScreen->WidthGet() - 50){
	   sounds[SCORE]->Play(NULL, false);
	   ball->Deinit();
	   ball->Init();
	   player->Deinit();
	   player->Init();
	   ai->Deinit();
	   ai->Init();
	   (*stats).playerScore += 1;
   }
   else{

	   if (ball->Update(dt, objects)){
		   sounds[HIT]->Play(NULL, false);
	   }
	   player->Update(dt);
	   ai->Update(dt, ballPos);
   }

   // Return to the previous menu if the escape key is pressed.
   if(!theStates->StateChangeCheck() && theKeyboard->KeyJustPressed(KEY_ESCAPE))
   {
      theMainGame->StateChangeTransitionBegin(true);
      theStates->Pop();
   }
}

//-----------------------------------------------------------------------------

void MainGame::Draw()
{
	Image* imgScore;

	int offset = 50;
	int offset2 = offset + 8;
	imgScore = theImages->Load("background");
	imgScore->Draw(Point2F::Create(0, 0));

	if ((*stats).gameMode == 0){
		if ((*stats).winCon == 1){
			imgScore = theImages->Load("victory");
			imgScore->Draw(Point2F::Create(600, 600));
			if (stats->playedFlag == 0){
				sounds[VICTORY]->Play(NULL, false);
				stats->playedFlag = 1;
			}
			return;
		}
		else if ((*stats).winCon == -1){
			imgScore = theImages->Load("defeat");
			imgScore->Draw(Point2F::Create(600, 600));
			if (stats->playedFlag == 0){
				sounds[DEFEAT]->Play(NULL, false);
				stats->playedFlag = 1;
			}
			return;
		}
	}
	else{
		if ((*stats).winCon == 1){
			imgScore = theImages->Load("p1Victory");
			imgScore->Draw(Point2F::Create(600, 300));
			if (stats->playedFlag == 0){
				sounds[VICTORY]->Play(NULL, false);
				stats->playedFlag = 1;
			}
			return;
		}
		else if ((*stats).winCon == -1){
			imgScore = theImages->Load("p2Victory");
			imgScore->Draw(Point2F::Create(600, 300));
			if (stats->playedFlag == 0){
				sounds[VICTORY]->Play(NULL, false);
				stats->playedFlag = 1;
			}
			return;
		}
	}

	switch ((*stats).aiScore){
	case 1:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 2:
		imgScore = theImages->Load("two");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 3:
		imgScore = theImages->Load("three");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 4:
		imgScore = theImages->Load("four");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 5:
		imgScore = theImages->Load("five");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 6:
		imgScore = theImages->Load("six");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 7:
		imgScore = theImages->Load("seven");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 8:
		imgScore = theImages->Load("eight");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 9:
		imgScore = theImages->Load("nine");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	case 10:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		imgScore = theImages->Load("zero");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset + imgScore->WidthGet() + 20, 40));
		break;
	case 11:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset + imgScore->WidthGet() + 20, 40));
		break;
	case 12:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		imgScore = theImages->Load("two");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset + imgScore->WidthGet() + 20, 40));
		break;
	case 13:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		imgScore = theImages->Load("three");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset + imgScore->WidthGet() + 20, 40));
		break;
	case 14:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		imgScore = theImages->Load("four");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset + imgScore->WidthGet() + 20, 40));
		break;
	default:
		imgScore = theImages->Load("zero");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 + offset, 40));
		break;
	}
	switch ((*stats).playerScore){
	case 1:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 2:
		imgScore = theImages->Load("two");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 3:
		imgScore = theImages->Load("three");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 4:
		imgScore = theImages->Load("four");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 5:
		imgScore = theImages->Load("five");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 6:
		imgScore = theImages->Load("six");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 7:
		imgScore = theImages->Load("seven");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 8:
		imgScore = theImages->Load("eight");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 9:
		imgScore = theImages->Load("nine");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 10:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2 - imgScore->WidthGet() - 20, 40));
		imgScore = theImages->Load("zero");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 11:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2 - imgScore->WidthGet() - 20, 40));
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 12:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2 - imgScore->WidthGet() - 20, 40));
		imgScore = theImages->Load("two");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 13:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2 - imgScore->WidthGet() - 20, 40));
		imgScore = theImages->Load("three");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	case 14:
		imgScore = theImages->Load("one");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2 - imgScore->WidthGet() - 20, 40));
		imgScore = theImages->Load("four");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	default:
		imgScore = theImages->Load("zero");
		imgScore->Draw(Point2F::Create(theScreen->WidthGet() / 2 - offset2, 40));
		break;
	}
   ball->Draw();
   player->Draw();
   ai->Draw();
   
}

//==============================================================================

