#include "Frog.h"
#include "MainGame.h"
#include "MainUpdate.h"
#include "KeyboardManager.h"
#include "KeyboardCommon.h"



using namespace Webfoot;

MainGame MainGame::instance;

//==============================================================================

/// Main GUI
#define GUI_LAYER_NAME "MainGame"



unsigned int dt;
//global variables
float ball_x;
float ball_y;
float ball_position_x;
float ball_position_y;

float player_position_x;
float player_position_y;

float player2_position_x;
float player2_position_y;

bool leftloss = false;
bool rightloss = false;

int player_points = 0;
int ai_points = 0;


//-----------------------------------------------------------------------------

MainGame::MainGame()
{
	ball = NULL;
	player = NULL;
	player2 = NULL;
}

//-----------------------------------------------------------------------------

void MainGame::Init()
{
	Inherited::Init();
	
	

	ball = frog_new Ball();
	ball->Init();

	player = frog_new Player();
	player->Init();

	player2 = frog_new Player2();
	player2->Init();


}

//-----------------------------------------------------------------------------

void MainGame::Deinit()
{
	theAnimatedBackgrounds->BackgroundClear();

	// Deinitialize and delete the ball.
	if (ball)
	{
		ball->Deinit();
		frog_delete ball;
		ball = NULL;
	}
	if (player)
	{
		player->Deinit();
		frog_delete player;
		player = NULL;
	}
	if (player2)
	{
		player2->Deinit();
		frog_delete player2;
		player2 = NULL;
	}

	Inherited::Deinit();
}

//-----------------------------------------------------------------------------

const char* MainGame::GUILayerNameGet()
{
	return GUI_LAYER_NAME;
}

//-----------------------------------------------------------------------------

void MainGame::Update()
{
	Inherited::Update();

	unsigned int dt = theClock->LoopDurationGet();

	 if (leftloss == true || rightloss == true){
		ball->Deinit();
		if (leftloss == true){
			DebugPrintf("ai point");
			ai_points += 1;
		}
		else if (rightloss == true){
			DebugPrintf("player point");
			player_points += 1;
		}
		leftloss = false;
		rightloss = false;
		ball->Init();
	} 
	 ball->Update(dt);
	 player->Update(dt);
	 player2->Update(dt);
	 if (player_points >= 15 || ai_points >= 15){
		 DebugPrintf("game over");
		 ball->Deinit();
		 player->Deinit();
		 player2->Deinit();
	 }



	// Return to the previous menu if the escape key is pressed.
	if (!theStates->StateChangeCheck() && theKeyboard->KeyJustPressed(KEY_ESCAPE))
	{
		theMainGame->StateChangeTransitionBegin(true);
		theStates->Pop();
	}
}

//-----------------------------------------------------------------------------

void MainGame::Draw()
{
	Image* bg;
	bg = theImages->Load("background");
	bg->Draw(Point2F::Create(0, 0));

	DrawText;
	
	ball->Draw();
	player->Draw();
	player2->Draw();

}

//==============================================================================
Player::Player()
{
	// Initialize pointers to NULL for safety.
	image = NULL;

}
Player2::Player2()
{
	// Initialize pointers to NULL for safety.
	image = NULL;

}

Ball::Ball()
{
	// Initialize pointers to NULL for safety.
	image = NULL;

}


//------------------------------------------------------------------------------
void Player::Init()
{
	// Load the image of the ball.
	image = theImages->Load("korn");

	// Start the ball in the middle of the screen.
	position = Point2F::Create(theScreen->SizeGet() / 2);

	//velocity.Set
}
void Player2::Init()
{
	// Load the image of the ball.
	image = theImages->Load("korn");

	// Start the ball in the middle of the screen.
	position = Point2F::Create(theScreen->SizeGet() / 2);

	//velocity.Set
}

void Ball::Init()
{
	// Load the image of the ball.
	image = theImages->Load("ghost");

	// Start the ball in the middle of the screen.
	position = Point2F::Create(theScreen->SizeGet() / 2);

	//velocity.Set
}

//------------------------------------------------------------------------------
void Player::Deinit()
{
	// Unload the image of the ball.
	if (image)
	{
		theImages->Unload(image);
		image = NULL;
	}
}
void Player2::Deinit()
{
	// Unload the image of the ball.
	if (image)
	{
		theImages->Unload(image);
		image = NULL;
	}
}
void Ball::Deinit()
{
	// Unload the image of the ball.
	if (image)
	{
		theImages->Unload(image);
		image = NULL;
	}
}
//-----------------------------------------------------------------------------
//point scoring, and collision methods
bool Ball::LeftCollision(float x, float y)

{
	//working :)
	if (X < 0){
		if ((position.x - radius)  <= (x + 40) && position.y<=(y + 100) && position.y >=(y) ){
			
			return true;
		}
	}
	else {
		return false;
	}

}
bool Ball::RightCollision(float x, float y)

{
	//WORKING PLEASE DONT TOUCH
	if (X > 0) {
		if (position.x > 950 && position.y <= (y + 100) && position.y >= (y)){
			
			return true;
		}
		else if (position.x > 100){
			return false;
		}
		else {
			return false;
		}
	}
	else{
		return false;
	}
}

bool Ball::PlayerPoint(){
	if (position.x < 10){
		player_points += 1;
		return true;
	}
	else{
		return false;
	}
}

bool Ball::AIPoint(){
	if (position.x > 1000){
		ai_points += 1;
		return true;
	}
	else{
		return false;
	}
}


//------------------------------------------------------------------------------


//update methods
void Ball::Update(unsigned int dt)

{
	Point2F positionScreen = Point2F::Create(theScreen->SizeGet());

	 if (positionScreen.x < position.x){
		X *= -1;
	}
	else if (position.x < 0){
		X *= -1;
	}
	if (positionScreen.y < position.y){
		Y *= -1;
	}
	else if (position.y < 0){
		Y *= -1;
	}
	if (LeftCollision(player_position_x, player_position_y) == true ){
		X *= -1;
	}
	//error
	if (RightCollision(player2_position_x, player2_position_y) == true){
		X *= -1;
	}

	position.Set(position.x + X, position.y + Y);

	//global variables
	ball_x = X;
	ball_y = Y;
	ball_position_x = (float)(position.x + X);
	ball_position_y = (float)(position.y + Y);

	//past the paddles
	leftloss = PlayerPoint();
	rightloss = AIPoint();
}


void Player::Update(unsigned int dt)
{

	
	Point2F positionScreen = Point2F::Create(theScreen->SizeGet());
	//we keep the paddle at x= 20;
	position.x = 20;

	//player can move the paddle up with w, and down with s
	
		if (!theStates->StateChangeCheck() && theKeyboard->KeyPressed(KEY_W) && position.y > 2){
			position.y -= 10;
		}


		if (!theStates->StateChangeCheck() && theKeyboard->KeyPressed(KEY_S) && position.y < 625){
			position.y += 10;
		}
	

	//global variables
	player_position_x = position.x + player_X;
	player_position_y = position.y + player_Y;
}

void Player2::Update(unsigned int dt)
{
	Point2F positionScreen = Point2F::Create(theScreen->SizeGet());
	position.x = 985;

	//AI movement
	int fail = rand() % 10;

		//ai can only see the ball for part of the screen
	//movement looks organic
	if ( ball_position_x < 970 && ball_x > 0) {
		
		//if the ball is going down on the screen
		if (ball_y > 0 && position.y < 625){
			position.y += 5;
		}

		//if the ball is going up on the screen
		else if (ball_y < 0 && position.y > 0){
			position.y -= 5;
		}
	}
	//ai automatically goes to ball here

	else if (ball_position_x > 400 && ball_position_x >= 970 && ball_position_x < 986 && ball_x > 0) {
		
			if (fail != 5){

				position.y = ball_position_y - 50;
			}
			else if (fail = 5 && ball_position_y < 350){
				position.y += 300;
			}
			else if (fail = 5 && ball_position_y > 350){
				position.y -= 300;


			}
		}
	

	//global variables
	player2_position_x = position.x + X;
	player2_position_y = position.y + Y;
	
}


//------------------------------------------------------------------------------
void Player::Draw()
{

	// The center of the ball is in the center of the image, so use an offset.
	image->Draw(position);
}
void Player2::Draw()
{

	// The center of the ball is in the center of the image, so use an offset.
	image->Draw(position);
}


void Ball::Draw()
{
	// The center of the ball is in the center of the image, so use an offset.
	image->Draw(position - (Point2F::Create(image->SizeGet()) / 2.0f));
}

//------------------------------------------------------------------------------
