#ifndef __MAINGAME_H__
#define __MAINGAME_H__

#include "Frog.h"
#include "MenuState.h"

namespace Webfoot {

	class Ball;
	class Player;
	class Player2;
	class Zero;
	class One;
	class Two;
	class Three;
	class Four;
	class Five;
	class Six;
	class Seven;
	class Eight;
	class Nine;
	class Ten;
	class Eleven;
	class Twelve;
	class Thirteen;
	class Fourteen;
	class Fifteen;
	


	//==============================================================================

	class MainGame : public MenuState
	{
	public:
		typedef MenuState Inherited;

		MainGame();
		virtual ~MainGame() {};

		virtual void Init();
		virtual void Deinit();

		/// Call this on every frame to update the positions.
		virtual void Update();
		/// Call this on every frame to draw the images.
		virtual void Draw();

		static MainGame instance;

	protected:
		/// Returns the name of the GUI layer
		virtual const char* GUILayerNameGet();

		/// The ball that bounces around the screen.
		Ball* ball;
		Player* player;
		Player2* player2;
		Zero* zero;
		One* one;
		Two* two;
		Three* three;
		Four* four;
		Five* five;
		Six* six;
		Seven* seven;
		Eight* eight;
		Nine* nine;
		Ten* ten;
		Eleven* eleven;
		Twelve* twelve;
		Thirteen* thirteen;
		Fourteen* fourteen;
		Fifteen* fifteen;


	};

	MainGame* const theMainGame = &MainGame::instance;

	//==============================================================================

	/// A bouncing ball
	class Ball
	{
	public:
		Ball();
		float speed = -7.00;
		float X = speed;
		float Y = speed;
		int radius = 30 / 2;

		/// Initialize the ball
		void Init();
		/// Clean up the ball
		void Deinit();

		bool LeftCollision(float x, float y);
		bool RightCollision(float x, float y);
		bool PlayerPoint();
		bool AIPoint();
		int BallPositionX();
		int BallPositionY();
		/// Make any changes for the given frame.  'dt' is the amount of time that
		/// has passed since the last frame, in milliseconds.
		void Update(unsigned int dt);
		/// Draw the ball.
		void Draw();

		//make a topcorner, bottom corner and middle velocity
		float Velocity();

	protected:
		/// Appearance of the ball.
		Image* image;
		/// Current position of the ball.
		Point2F position;
	};

	class Player
	{
	public:
		Player();
		float player_speed = 5;
		float player_X = player_speed;
		float player_Y = player_speed;
		/// Initialize the ball
		void Init();
		/// Clean up the ball
		void Deinit();

		/// Make any changes for the given frame.  'dt' is the amount of time that
		/// has passed since the last frame, in milliseconds.
		void Update(unsigned int dt);
		/// Draw the ball.
		void Draw();

	protected:
		/// Appearance of the ball.
		Image* image;
		/// Current position of the ball.
		Point2F position;
	};

	class Player2
	{
	public:
		Player2();
		float speed = 10;
		float X = speed;
		float Y = speed;

		/// Initialize the ball
		void Init();
		/// Clean up the ball
		void Deinit();

		void Move(int ball_x, int ball_y);
		/// Make any changes for the given frame.  'dt' is the amount of time that
		/// has passed since the last frame, in milliseconds.
		void Update(unsigned int dt);
		/// Draw the ball.
		void Draw();

	protected:
		/// Appearance of the ball.
		Image* image;
		/// Current position of the ball.
		Point2F position;
	};

	//==============================================================================
	class Zero
	{
	public:
		Zero();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class One
	{
	public:
		One();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};

	class Two
	{
	public:
		Two();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Three
	{
	public:
		Three();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Four
	{
	public:
		Four();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Five
	{
	public:
		Five();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Six
	{
	public:
		Six();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Seven
	{
	public:
		Seven();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Eight
	{
	public:
		Eight();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Nine
	{
	public:
		Nine();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Ten
	{
	public:
		Ten();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Eleven
	{
	public:
		Eleven();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Twelve
	{
	public:
		Twelve();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Thirteen
	{
	public:
		Thirteen();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Fourteen
	{
	public:
		Fourteen();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
	class Fifteen
	{
	public:
		Fifteen();
		void Init();
		void Deinit();
		void Update(unsigned int dt);
		void Draw();

	protected:
		Image* image;

		Point2F position;
	};
} //namespace Webfoot {

#endif //#ifndef __MAINGAME_H__
